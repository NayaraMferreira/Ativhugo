package ifpr.pgua.eic.colecaomusicas;

public class Laucher {
    
    public static void main(String[] args) {
        App.launch(App.class, args);
    }
}
